require('../tooltip/tooltip.css');
module.exports = require('./index-nocss.js');
